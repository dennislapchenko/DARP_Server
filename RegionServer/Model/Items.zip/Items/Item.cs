﻿//using System;
//using RegionServer.Model.Interfaces;
//
//namespace RegionServer.Model.Items
//{
//	public class Item : IItem
//	{
//		public Item()
//		{
//		}
//
//		#region IItem implementation
//
//		public string Name {get; set;}
//		public int ItemId {get; set;}
//		public ItemType Type {get; set;}
//		public int Value {get; set;}
//		public bool Equippable {get; set;}
//		public IStatHolder Stats {get; set;}
//
//		#endregion
//	}
//}
//