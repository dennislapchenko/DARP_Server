﻿//namespace RegionServer.Model.Items
//{
//	public enum ItemType
//	{
//		Weapon,
//		Armor,
//		Consumable,
//		Material
//	}
//}
//