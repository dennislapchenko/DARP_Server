﻿//using System;
//using System.Collections.Generic;
//using RegionServer.Model.Interfaces;
//
//namespace RegionServer.Model.Items
//{
//	public class ItemDBCache
//	{
//		public static Dictionary<int, IItem> Items;
//
//		public ItemDBCache()
//		{
//			Items = new Dictionary<int, IItem>();
//			Items.Add(3, new Item() { Name = "dzermo", Type = ItemType.Weapon});
//		}
//
//		public static string GetItemName(int itemId)
//		{
//			IItem result;
//			Items.TryGetValue(itemId, out result);
//			if(result != null)
//			{
//				return result.Name;
//			}
//			return null;
//		}
//	}
//}